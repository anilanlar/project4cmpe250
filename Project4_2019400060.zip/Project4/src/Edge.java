
public class Edge {

	int from_index;
	int to_index;
	int capacity_of_edge;
	int flow=0;
	Edge residual_Edge;
	


	public Edge(int from, int to, int capacity) {
		this.from_index=from;
		this.to_index=to;
		this.capacity_of_edge=capacity;
	}
	
	
	
	public int remainingCapacity() {
		int remaining_Capacity= capacity_of_edge - flow;
		return remaining_Capacity;
	}

	
}
