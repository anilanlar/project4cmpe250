import java.util.*;

 

public class Dinitz {

	static int numberOfNodes;

	int source_index = 0;

	int sink_index = numberOfNodes - 1;

	// array holding levels of nodes
	int[] level = new int[numberOfNodes];

	ArrayList<Edge>[] graph_Array;

	public Dinitz() {
		graph_Array = new ArrayList[numberOfNodes];

		int sizeOfGraphArray = graph_Array.length;
		
		int counter = 0;
		
		while(counter< sizeOfGraphArray) {
			graph_Array[counter] = new ArrayList<Edge>();
			counter++;
		}
		
	
		
	}

	public int maxFlowFinder() {

		int[] visited_Array = new int[numberOfNodes];
		int maximum_Flow = 0;
		
		boolean isReachable= true;
		
		isReachable= breadth_first_search(isReachable);

		while (isReachable) {
			//System.out.println(isReachable);
			for (int i = 0; i < visited_Array.length; i++) {
				visited_Array[i] = 0;
			}

			// Find max flow by adding all augmenting path flows.
			int flow = 1;
			
			while (flow != 0) {
				flow = depth_first_search(source_index, visited_Array,Integer.MAX_VALUE, 0 );
				maximum_Flow += flow;
			}
			
			isReachable=  breadth_first_search(isReachable);

		}

		return maximum_Flow;
	}
	
	public boolean breadth_first_search(boolean isReachable_bool) {
		
		for (int i = 0; i < level.length; i++) {
			level[i] = -1;
		}
		
		level[source_index]= 0;
		
		int current_Node_index= source_index;
		
		Queue<Integer> indices_to_be_checked= new LinkedList<Integer>(); 
		indices_to_be_checked.add(current_Node_index);
		
		while(!indices_to_be_checked.isEmpty()&& level[numberOfNodes-1]==-1){
			current_Node_index= indices_to_be_checked.poll();
			for(Edge edgeToBeTraveled: graph_Array[current_Node_index]) {
				if( !(edgeToBeTraveled.capacity_of_edge-edgeToBeTraveled.flow>0)) {
					continue;
				}
				if(!(level[edgeToBeTraveled.to_index]==-1)) {
					continue;
				}
				else {
					level[edgeToBeTraveled.to_index]= level[current_Node_index]+1;
					indices_to_be_checked.add(edgeToBeTraveled.to_index);
				}

			}
		}
		
		if(level[numberOfNodes-1]==-1) {
			return false;
		}
		else {
			return true;
		}
		
	}
	
	

	public int depth_first_search(int current_node, int[] visited_Array, int flow, int source_index_number) {

		if (current_node== sink_index) {
			return flow;
		}
			
		while (visited_Array[current_node] < graph_Array[current_node].size()) {
			
 			ArrayList<Edge> arrayList = graph_Array[current_node];
 			
 			int nextEdgeToBeTried = visited_Array[current_node];
			
			Edge edge = arrayList.get(nextEdgeToBeTried);

			
			
			if (!(edge.capacity_of_edge- edge.flow > 0)) {
				visited_Array[current_node]++;

				continue; 
			}
			if(!(level[edge.to_index] == level[current_node] + 1)) {
				visited_Array[current_node]++;

				continue;
			}
			
			int newBottleNeck= 0;
			if(flow < edge.capacity_of_edge- edge.flow) {
				newBottleNeck=flow;
			}else {
				newBottleNeck= edge.capacity_of_edge- edge.flow;
			}

			int bottleNeck = depth_first_search(edge.to_index, visited_Array,newBottleNeck,0 );
			
			if (bottleNeck > 0) {
				
				edge.flow+=bottleNeck;
				
				edge.residual_Edge.flow-=bottleNeck;

				return bottleNeck;
			}
			visited_Array[current_node]++;

		}
		return 0;
	}

	public void newEdgeCreation(int from_index, int to_index, int capacity) {
		
//		if ( capacity <= 0 ) {
//	        throw new IllegalArgumentException("Forward edge capacity <= 0");   
//	      } 

		Edge edge = new Edge(from_index, to_index, capacity);
		graph_Array[from_index].add(edge);
		backEdgeCreation(edge, from_index, to_index, capacity);
	}
	public void backEdgeCreation(Edge regular_edge ,int from_index, int to_index, int capacity) {
		
		Edge backEdge = new Edge(to_index, from_index, 0);
		graph_Array[to_index].add(backEdge);
		backEdge.residual_Edge = regular_edge;
		regular_edge.residual_Edge=backEdge;
	}
	
	
 

}
