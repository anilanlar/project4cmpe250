//
//public class SantaGraph {
//	
//	static int numberOfVertices;
//
//	static SantaNode[] santaNodeArray;
//	
//	static int[][] capacity_matrix;
//	
//	static int[][] flow_matrix;
//	
//	
//	public static int findMaxFlow(){
//		
//		
//		preflow(numberOfVertices);
//
//		int excessNode_int = excessNodeFinder();
//		
//		while(excessNode_int!=-1) {
//			System.out.println("--------");
//			
//			System.out.println("from: "+ excessNode_int );
//			SantaGraph.santaNodeArray[santaNodeArray.length-1].heightOfNode=0;
//
//			// pushing the flow from the node having excess flow
//			if(pushFrom(excessNode_int)) {
//				
//			}else {
//				//If there is excess flow and it doesn't let flow to go, we have to make changes on heights
//				System.out.println("relabeled node index "+excessNode_int);
//				relabelNode(excessNode_int);
//
//			}
//		//	santaNodeArray[0].excessFlowOfNode=0;
//			excessNode_int= excessNodeFinder();
//			if(excessNode_int==-1) {
//				System.out.println("KAKAA");
//			}
//		}
//		
//		// return the max value of flow i.e that of sink node
//		return santaNodeArray[santaNodeArray.length-1].excessFlowOfNode;
//		
//	}
//	
//	
//	
//	public static void preflow(int sourceNode_height){
//    	
//		int sourceNode_index= 0;
//		
//    	santaNodeArray[sourceNode_index].heightOfNode= sourceNode_height;
//    	
//    	for(int j=0; j<numberOfVertices; j++) {
//    		int lengthOfEdgeFromSourceToAdjacent = capacity_matrix[0][j];
//    		
//			System.out.println("FROM SOURCE to: "+ j+ "  pushed amount"+ lengthOfEdgeFromSourceToAdjacent);
//    		
//			
//			
//    		flow_matrix[0][j]=lengthOfEdgeFromSourceToAdjacent;
//    		
//            santaNodeArray[j].excessFlowOfNode += lengthOfEdgeFromSourceToAdjacent;
//            
//            // Back Edge from adjacent to source node
//            editCapacityMatrix(j, 0, 0);
//            
//            flow_matrix[j][0]= -1 * lengthOfEdgeFromSourceToAdjacent;
//    	}
//		
//    }
//	
//	public static void editCapacityMatrix(int firstNode, int secondNode, int newLengthValue){
//		capacity_matrix[firstNode][secondNode] = newLengthValue;
//	//	capacity_matrix[secondNode][firstNode] = -newLengthValue;
//
//		
//	}
//	
//	public static boolean pushFrom(int firstNode_int){
//		
//		
//    	for(int destinationNode_int=0; destinationNode_int<numberOfVertices; destinationNode_int++) {
//		
//    		if(capacity_matrix[firstNode_int][destinationNode_int]!=0  &&(flow_matrix[firstNode_int][destinationNode_int]!=capacity_matrix[firstNode_int][destinationNode_int])) {
//    			
//    			SantaNode baseNode = santaNodeArray[firstNode_int];
//    			
//    			SantaNode destinationNode = santaNodeArray[destinationNode_int];
//    			
//    			//If base is at a higher level, then push
//    			if(baseNode.heightOfNode> destinationNode.heightOfNode) { 				
//    				int availabilityOfEdge = capacity_matrix[firstNode_int][destinationNode_int] - flow_matrix[firstNode_int][destinationNode_int];
//
//    				
//        			int amountToBePushed = Math.min(baseNode.excessFlowOfNode, availabilityOfEdge);
//
//
//        			System.out.println("excessten gelen: "+ baseNode.excessFlowOfNode);
//        			System.out.println("edge'ten gelen "+ availabilityOfEdge);
//        			
//    				System.out.println("to: "+ destinationNode_int+ "  pushed amount"+ amountToBePushed);
//    				
//
//        			// Updating excess_flow values of first and destination nodes
//    				
//    				flow_matrix[firstNode_int][destinationNode_int]+= amountToBePushed;
//    				flow_matrix[destinationNode_int][firstNode_int]-=amountToBePushed;
//    				
//    				capacityMatrixPrinter();
//    				System.out.println("EKSES VALUE: "+baseNode.excessFlowOfNode);
//    				flowMatrixPrinter();        			
//        			baseNode.excessFlowOfNode -= amountToBePushed;
//        			
//        			if(baseNode.nodeID==5) {
//        				
//        			}
//        			
//        			destinationNode.excessFlowOfNode += amountToBePushed;
//        			
//    				//currentExcessPrinter();
//        			return true;
//    			}
//    			
//    		}
//	
//    	}
//    	return false;
//	}
//	
//	//???????????
//	public static void changeFlowMatrix(int firstNodeNumber,int columnNumber, int change) {
//		if(columnNumber!=numberOfVertices-1) {
//			for(int i=0; i<numberOfVertices;i++) {
//				if(capacity_matrix[i][columnNumber]!=0) {
//					if(i==firstNodeNumber) {
//						continue;
//					}
//					
//					flow_matrix[i][columnNumber] += change;
//					flow_matrix[columnNumber][i]-=change;
//				}
//				
//			}
//		}
//	}
//	
//	public static void relabelNode(int relabeledNode_int) {
//		
//		int minAdjacentHeight = Integer.MAX_VALUE;
//		
//    	for(int j=0; j<numberOfVertices; j++) {
//    		
//    		if(capacity_matrix[relabeledNode_int][j]!=0  &&(flow_matrix[relabeledNode_int][j]!=capacity_matrix[relabeledNode_int][j])) {
//    		
//    			if(santaNodeArray[j].heightOfNode < minAdjacentHeight) {
//    				
//    				minAdjacentHeight =  santaNodeArray[j].heightOfNode;
//    				    //	System.out.println("min adjacent: "+ minAdjacentHeight);
//
//    				santaNodeArray[relabeledNode_int].heightOfNode = minAdjacentHeight+1;
//    				
//    			}
//    				
//    			
//    			
//    		}    		
//    	}
//    	System.out.println("relabeled new height "+santaNodeArray[relabeledNode_int].heightOfNode);
//		
//	}
//	
//	public static int excessNodeFinder() {
//		
//    	for(int j=0; j<numberOfVertices; j++) {
//    		
//    		// This node has excessFlow
//    		
//    		if(j==5) {
//    			System.out.println("ekselanselo "+santaNodeArray[j].toString());
//    		}
//    		
//    		if(santaNodeArray[j].excessFlowOfNode>0) {
//    			
//    			SantaNode currentSantaNode= santaNodeArray[j];
//
//    			
//    			for (int index=0; index<numberOfVertices; index++) {
//    				
//    				if( capacity_matrix[j][index]!=0 &&capacity_matrix[j][index]!=flow_matrix[j][index]) {
//    					
//    					
//    					//System.out.println("J YANI EXCESS NODE INDEX "+ j);
//    					return j;
//    					
//    				}else {
//    				//	System.out.print("BOYNU BÜKÜK"+ j+"   "); System.out.println(capacity_matrix[j][index]);
//    					
//
//    				}
//    				
//    			}
//    			
//    		}
//    		
//    	}
//		
//    	return -1;
//	}
//	
//	public static void currentExcessPrinter() {
//		System.out.println("%%%%% NEW EXCESS VALUES %%%%%");
//		for(int i=0; i<numberOfVertices;i++) {
//			System.out.println(santaNodeArray[i].excessFlowOfNode);
//		}
//
//	}
//	
//	
//	public static void flowMatrixPrinter() {
//		System.out.println("%%%% FLOW MATRIX SITUATION: %%%%%");
//		
//		for(int[] arrayler: flow_matrix) {
//			for(int j : arrayler) {
//				System.out.print(j+" ");
//			}
//			System.out.println();
//		}
//		
//		System.out.println("+++++++++++ FLOW MATRIX ENDS +++++++++++++++");
//
//	}
//	public static void capacityMatrixPrinter() {
//		System.out.println("%%%% CAPACITY MATRIX SITUATION: %%%%%");
//		
//		for(int[] arrayler: capacity_matrix) {
//			for(int j : arrayler) {
//				System.out.print(j+" ");
//			}
//			System.out.println();
//		}
//		
//		System.out.println("+++++++++++ CAPACITY MATRIX ENDS +++++++++++++++");
//
//	}
//
//	
//
//
//}
