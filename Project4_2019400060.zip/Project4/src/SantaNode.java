
public class SantaNode {

	int nodeID;
		
	int numberOfGiftsInTheBag=0;
	
	String typeOfNode;

	@Override
	public String toString() {
		return "SantaNode [nodeID=" + nodeID + ", numberOfGiftsInTheBag=" + numberOfGiftsInTheBag + ", typeOfNode="
				+ typeOfNode + "]";
	}


	
    
}
