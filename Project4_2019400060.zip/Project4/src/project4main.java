import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;


public class project4main {

	public static void main(String[] args) throws FileNotFoundException {

		File file = new File(args[0]);

		Scanner inputText = new Scanner(file);
		
		
		
		
		int greenTrainNumber = Integer.parseInt(inputText.nextLine());

		Integer[] greenTrainsCapacitiesArray = new Integer[greenTrainNumber];

		String nextLine1= inputText.nextLine();
		if(!nextLine1.equals("")) {
			trainReindeerCapacityArrayUpdater(nextLine1, greenTrainsCapacitiesArray);

		}
		
		
	//	trainReindeerCapacityArrayUpdater(inputText.nextLine(), greenTrainsCapacitiesArray);

		int redTrainNumber = Integer.parseInt(inputText.nextLine());

		Integer[] redTrainsCapacitiesArray = new Integer[redTrainNumber];

		String nextLine2= inputText.nextLine();

		if(!nextLine2.equals("")) {
			trainReindeerCapacityArrayUpdater(nextLine2, redTrainsCapacitiesArray);

		}
//////////////
		int greenReindeerNumber = Integer.parseInt(inputText.nextLine());

		Integer[] greenReindeersCapacitiesArray = new Integer[greenReindeerNumber];

		String nextLine3= inputText.nextLine();
		if(!nextLine3.equals("")) {
			trainReindeerCapacityArrayUpdater(nextLine3, greenReindeersCapacitiesArray);

		}
		
		
		

		int redReindeerNumber = Integer.parseInt(inputText.nextLine());

		Integer[] redReindeersCapacitiesArray = new Integer[redReindeerNumber];

		String nextLine4= inputText.nextLine();

		if(!nextLine4.equals("")) {
			trainReindeerCapacityArrayUpdater(nextLine4, redReindeersCapacitiesArray);

		}
		/////////////

		int numberOfBags = Integer.parseInt(inputText.nextLine());

		String[] bagsInformationArray = inputText.nextLine().split(" ");


		// Objects without a are created;

		SantaNode b = new SantaNode();
		b.typeOfNode = "b";
		boolean bFirstTime = true;

		SantaNode bd = new SantaNode();
		bd.typeOfNode = "bd";
		boolean bdFirstTime = true;


		SantaNode be = new SantaNode();
		be.typeOfNode = "be";
		boolean beFirstTime = true;


		SantaNode c = new SantaNode();
		c.typeOfNode = "c";
		boolean cFirstTime = true;


		SantaNode cd = new SantaNode();
		cd.typeOfNode = "cd";
		boolean cdFirstTime = true;

		SantaNode ce = new SantaNode();
		ce.typeOfNode = "ce";
		boolean ceFirstTime = true;


		SantaNode d = new SantaNode();
		d.typeOfNode = "d";
		boolean dFirstTime = true;


		SantaNode e = new SantaNode();
		e.typeOfNode = "e";
		boolean eFirstTime = true;


		int verticesNumberSourceSinkIncluded = 2;

		ArrayList<SantaNode> withAarrayList = new ArrayList<SantaNode>();
		
		ArrayList<SantaNode> withoutAarrayList = new ArrayList<SantaNode>();
		
		ArrayList<SantaNode> greenTrainArrayList = new ArrayList<SantaNode>();

		ArrayList<SantaNode> redTrainArrayList = new ArrayList<SantaNode>();

		ArrayList<SantaNode> greenReindeerArrayList = new ArrayList<SantaNode>();
		
		ArrayList<SantaNode> redReindeerArrayList = new ArrayList<SantaNode>();

		int NODEID=1;
		
		
		
		for (int i = 0; i < bagsInformationArray.length - 1; i++) {

			/// WITH A
			if (bagsInformationArray[i].equals("a")) {
				SantaNode newAobject = new SantaNode();
				newAobject.typeOfNode = "a";
				newAobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newAobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newAobject);  
				verticesNumberSourceSinkIncluded += 1;
			}

			if (bagsInformationArray[i].equals("ab")) {
				SantaNode newABobject = new SantaNode();
				newABobject.typeOfNode = "ab";
				newABobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newABobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newABobject);
				verticesNumberSourceSinkIncluded += 1;
			}

			if (bagsInformationArray[i].equals("abd")) {
				SantaNode newABDobject = new SantaNode();
				newABDobject.typeOfNode = "abd";
				newABDobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newABDobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newABDobject);
				verticesNumberSourceSinkIncluded += 1;
			}

			if (bagsInformationArray[i].equals("abe")) {
				SantaNode newABEobject = new SantaNode();
				newABEobject.typeOfNode = "abe";
				newABEobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newABEobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newABEobject);
				verticesNumberSourceSinkIncluded += 1;
			}

			if (bagsInformationArray[i].equals("ac")) {
				SantaNode newACobject = new SantaNode();
				newACobject.typeOfNode = "ac";
				newACobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newACobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newACobject);
				verticesNumberSourceSinkIncluded += 1;
			}

			if (bagsInformationArray[i].equals("acd")) {
				SantaNode newACDobject = new SantaNode();
				newACDobject.typeOfNode = "acd";
				newACDobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newACDobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newACDobject);
				verticesNumberSourceSinkIncluded += 1;
			}

			if (bagsInformationArray[i].equals("ace")) {
				SantaNode newACEobject = new SantaNode();
				newACEobject.typeOfNode = "ace";
				newACEobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newACEobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newACEobject);
				verticesNumberSourceSinkIncluded += 1;
			}

			if (bagsInformationArray[i].equals("ad")) {
				SantaNode newADobject = new SantaNode();
				newADobject.typeOfNode = "ad";
				newADobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newADobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newADobject);
				verticesNumberSourceSinkIncluded += 1;
			}

			if (bagsInformationArray[i].equals("ae")) {
				SantaNode newAEobject = new SantaNode();
				newAEobject.typeOfNode = "ae";
				newAEobject.numberOfGiftsInTheBag = Integer.parseInt(bagsInformationArray[i + 1]);
				newAEobject.nodeID=NODEID;
				NODEID+=1;
				withAarrayList.add(newAEobject);
				verticesNumberSourceSinkIncluded += 1;
			}

			/// WITHOUT A

			if (bagsInformationArray[i].equals("b")) {
				if (bFirstTime) {
					verticesNumberSourceSinkIncluded += 1;
					b.nodeID=NODEID;
					NODEID+=1;
					withoutAarrayList.add(b);
					bFirstTime=false;
				}
				b.numberOfGiftsInTheBag += Integer.parseInt(bagsInformationArray[i + 1]);
			}

			if (bagsInformationArray[i].equals("bd")) {
				if (bdFirstTime) {
					verticesNumberSourceSinkIncluded += 1;
					bd.nodeID=NODEID;
					NODEID+=1;
					withoutAarrayList.add(bd);
					bdFirstTime = false;
				}
				bd.numberOfGiftsInTheBag += Integer.parseInt(bagsInformationArray[i + 1]);
			}

			if (bagsInformationArray[i].equals("be")) {
				if (beFirstTime) {
					verticesNumberSourceSinkIncluded += 1;
					be.nodeID=NODEID;
					NODEID+=1;
					withoutAarrayList.add(be);
					beFirstTime= false;
				}
				be.numberOfGiftsInTheBag += Integer.parseInt(bagsInformationArray[i + 1]);
			}

			if (bagsInformationArray[i].equals("c")) {
				if (cFirstTime) {
					verticesNumberSourceSinkIncluded += 1;
					c.nodeID=NODEID;
					NODEID+=1;
					withoutAarrayList.add(c);
					cFirstTime= false;
				}
				c.numberOfGiftsInTheBag += Integer.parseInt(bagsInformationArray[i + 1]);
			}

			if (bagsInformationArray[i].equals("cd")) {
				if (cdFirstTime) {
					verticesNumberSourceSinkIncluded += 1;
					cd.nodeID=NODEID;
					NODEID+=1;
					withoutAarrayList.add(cd);
					cdFirstTime= false;
				}
				cd.numberOfGiftsInTheBag += Integer.parseInt(bagsInformationArray[i + 1]);
			}

			if (bagsInformationArray[i].equals("ce")) {
				if (ceFirstTime) {
					verticesNumberSourceSinkIncluded += 1;
					ce.nodeID=NODEID;
					NODEID+=1;
					withoutAarrayList.add(ce);
					ceFirstTime = false;
				}
				ce.numberOfGiftsInTheBag += Integer.parseInt(bagsInformationArray[i + 1]);
			}

			if (bagsInformationArray[i].equals("d")) {
				if (dFirstTime) {
					verticesNumberSourceSinkIncluded += 1;
					d.nodeID=NODEID;
					NODEID+=1;
					withoutAarrayList.add(d);
					dFirstTime = false;
				}
				d.numberOfGiftsInTheBag += Integer.parseInt(bagsInformationArray[i + 1]);
			}

			if (bagsInformationArray[i].equals("e")) {
				if (eFirstTime) {
					verticesNumberSourceSinkIncluded += 1;
					e.nodeID=NODEID;
					NODEID+=1;
					withoutAarrayList.add(e);
					eFirstTime= false;
				}
				e.numberOfGiftsInTheBag += Integer.parseInt(bagsInformationArray[i + 1]);
			}

			i++;
		}
		
		//Vehiclesarraylist doldurma
		int sinkaydi= 2+ withAarrayList.size()+withoutAarrayList.size()+ greenTrainNumber+greenReindeerNumber+ redTrainNumber+redReindeerNumber;

		
		
		
		
		//an object to carry out dinitz algorithm is created
		Dinitz.numberOfNodes=sinkaydi;
		Dinitz dinitz= new Dinitz();



	//	System.out.println("A ILE OLANLAR");
		for(SantaNode objectWithA: withAarrayList) {
		//	System.out.println(objectWithA.toString());
		}
		
	//	System.out.println("A'SIZ OLANLAR");
		// dinitz.graph_Array icini dolduruyoruz
		for(SantaNode objectWithoutA: withoutAarrayList) {
			
		//	System.out.println(objectWithoutA.toString());
		}
//		
//		System.out.println("TRENLER VE RENGEYIKLERI");
		
//		printer(greenTrainsCapacitiesArray);
//		printer(redTrainsCapacitiesArray);
//		printer(greenReindeersCapacitiesArray); 
//		printer(redReindeersCapacitiesArray);
		
		vehiclesCreator(NODEID, greenTrainArrayList, redTrainArrayList, greenReindeerArrayList, redReindeerArrayList, greenTrainsCapacitiesArray, redTrainsCapacitiesArray, greenReindeersCapacitiesArray, redReindeersCapacitiesArray);
		
//		printerForArrayList(greenTrainArrayList);
//		printerForArrayList(redTrainArrayList);
//		printerForArrayList(greenReindeerArrayList);
//		printerForArrayList(redReindeerArrayList);

	//	int sinkaydi= 2+ withAarrayList.size()+withoutAarrayList.size()+ greenTrainNumber+greenReindeerNumber+ redTrainNumber+redReindeerNumber;
		
	//	System.out.println("sinkaydi: "+ sinkaydi);
		
		edgesCreator(sinkaydi, dinitz, withAarrayList, withoutAarrayList, greenTrainArrayList, redTrainArrayList, greenReindeerArrayList, redReindeerArrayList);
		
		
		
		
		
		
		
		int numberOfVehicles = greenReindeerNumber + greenTrainNumber + redReindeerNumber + redTrainNumber;

		verticesNumberSourceSinkIncluded += numberOfVehicles;

		// Creation of santanodeArray and vertices

//		SantaGraph.numberOfVertices = verticesNumberSourceSinkIncluded;
//
//		SantaGraph.santaNodeArray = new SantaNode[verticesNumberSourceSinkIncluded];
//
//		SantaGraph.capacity_matrix = new int[verticesNumberSourceSinkIncluded][verticesNumberSourceSinkIncluded];
//
//		SantaGraph.flow_matrix = new int[verticesNumberSourceSinkIncluded][verticesNumberSourceSinkIncluded];

		for (int i = 0; i < verticesNumberSourceSinkIncluded; i++) {
			SantaNode santana = new SantaNode();
			santana.nodeID = i;
			//SantaGraph.santaNodeArray[i] = santana;

		}

		// Putting A objects into the SantaGraph.santaNodeArray
		int numberOfAs = withAarrayList.size();

		for (int i = 1; i <= numberOfAs; i++) {
			withAarrayList.get(i - 1).nodeID = i;
			//SantaGraph.santaNodeArray[i] = withAarrayList.get(i - 1);
		}

		// Putting objects without A into the SantaGraph.santaNodeArray

		int startOfBags = numberOfAs + 1;

		if (b.numberOfGiftsInTheBag > 0) {
			b.nodeID=startOfBags;
			//SantaGraph.santaNodeArray[startOfBags] = b;
			startOfBags += 1;
		}
		if (bd.numberOfGiftsInTheBag > 0) {
			bd.nodeID=startOfBags;
			//SantaGraph.santaNodeArray[startOfBags] = bd;
			startOfBags += 1;
		}
		if (be.numberOfGiftsInTheBag > 0) {
			be.nodeID=startOfBags;
			//SantaGraph.santaNodeArray[startOfBags] = be;
			startOfBags += 1;
		}
		if (c.numberOfGiftsInTheBag > 0) {
			c.nodeID=startOfBags;
			//SantaGraph.santaNodeArray[startOfBags] = c;
			startOfBags += 1;
		}
		if (cd.numberOfGiftsInTheBag > 0) {
			cd.nodeID=startOfBags;
			//SantaGraph.santaNodeArray[startOfBags] = cd;
			startOfBags += 1;
		}
		if (ce.numberOfGiftsInTheBag > 0) {
			ce.nodeID=startOfBags;
			//SantaGraph.santaNodeArray[startOfBags] = ce;
			startOfBags += 1;
		}
		if (d.numberOfGiftsInTheBag > 0) {
			d.nodeID=startOfBags;

			//SantaGraph.santaNodeArray[startOfBags] = d;
			startOfBags += 1;
		}
		if (e.numberOfGiftsInTheBag > 0) {
			e.nodeID=startOfBags;

			//SantaGraph.santaNodeArray[startOfBags] = e;
			startOfBags += 1;
		}

		// Created Vehicles and added into SantaGraph.santaNodeArray

		
		
		// SOURCE AND SINK TYPE INSTANTIATION
//		SantaGraph.santaNodeArray[0].typeOfNode = "source";
//		SantaGraph.santaNodeArray[SantaGraph.santaNodeArray.length - 1].typeOfNode = "sink";


		

		// CREATION OF EDGES

		// A



//		// B AND OTHERS
//		for (int i = 0; i<withoutAarrayList.size(); i++) {
//			othersEdgeCreator(withoutAarrayList,dinitz,numberOfVehicles, verticesNumberSourceSinkIncluded, SantaGraph.santaNodeArray[i].nodeID, SantaGraph.santaNodeArray[i], SantaGraph.capacity_matrix);
//		}
//		
//		// RIGHTMOST PART OF THE GRAPH
//		
//		for(int i= startOfBags;i<SantaGraph.santaNodeArray.length-1; i++) {
//			SantaGraph.editCapacityMatrix(i, SantaGraph.santaNodeArray.length-1, SantaGraph.santaNodeArray[i].numberOfGiftsInTheBag);
//		}

		

		
		int totalGifts=0;
		for(SantaNode i: withAarrayList) {
			totalGifts+=i.numberOfGiftsInTheBag;
		}
		for(SantaNode i: withoutAarrayList) {
			totalGifts+=i.numberOfGiftsInTheBag;
		}
		
				


		int cevap= dinitz.maxFlowFinder();
        PrintStream output = new PrintStream(args[1]);

		output.print(totalGifts-cevap);
		//System.out.println(totalGifts-cevap);
		
		
//		for(int i=0; i<dinitz.graph_Array.length;i++ ) {
//			System.out.println("--------");
//			System.out.print("NODE NUMBER:"+i+"|||||||||");
//			for(int m=0; m< dinitz.graph_Array[i].size() ;m++) {
//				//System.out.print(m+". index : ");
//				System.out.print(dinitz.graph_Array[i].get(m).capacity_of_edge+" ");
//			}
//			System.out.println("");
//		}
//		
		
		
		
//		printerForArrayList(withAarrayList);
//		printerForArrayList(withoutAarrayList);
//
//		
//		
//		
//		
//		
		
		
		
	}
	

	public static void vehiclesCreator(int NODEID,ArrayList<SantaNode> greenTrainArrayList,ArrayList<SantaNode> redTrainArrayList,
			ArrayList<SantaNode> greenReindeerArrayList,
			ArrayList<SantaNode> redReindeerArrayList,
			Integer[] greenTrainsCapacitiesArray,Integer[] redTrainsCapacitiesArray,
			Integer[] greenReindeersCapacitiesArray,Integer[] redReindeersCapacitiesArray) {
		
		
		for(Integer i: greenTrainsCapacitiesArray) {
			SantaNode santaNode= new SantaNode();
			santaNode.nodeID= NODEID;
			NODEID+=1;
			santaNode.typeOfNode= "greentrain";
			santaNode.numberOfGiftsInTheBag= i;
			greenTrainArrayList.add(santaNode);
		}
		
		for(Integer i: redTrainsCapacitiesArray) {
			SantaNode santaNode= new SantaNode();
			santaNode.nodeID= NODEID;
			NODEID+=1;
			santaNode.typeOfNode= "redtrain";
			santaNode.numberOfGiftsInTheBag= i;
			redTrainArrayList.add(santaNode);
		}
		
		for(Integer i: greenReindeersCapacitiesArray) {
			SantaNode santaNode= new SantaNode();
			santaNode.nodeID= NODEID;
			NODEID+=1;
			santaNode.typeOfNode= "greenreindeer";
			santaNode.numberOfGiftsInTheBag= i;
			greenReindeerArrayList.add(santaNode);
		}
		
		for(Integer i: redReindeersCapacitiesArray) {
			SantaNode santaNode= new SantaNode();
			santaNode.nodeID= NODEID;
			NODEID+=1;
			santaNode.typeOfNode= "redreindeer";
			santaNode.numberOfGiftsInTheBag= i;
			redReindeerArrayList.add(santaNode);
		}

	}
	
	
	
	
	
	
	
	public static void helperEdgesCreator(SantaNode object, Dinitz dinitz,int santaNodeID, ArrayList<SantaNode> toBeIterated) {
		for(SantaNode i: toBeIterated) {
			if(i.numberOfGiftsInTheBag==0) {
				continue;
			}

			dinitz.newEdgeCreation(santaNodeID, i.nodeID, object.numberOfGiftsInTheBag);
		}
	}
	public static void AhelperEdgesCreator(SantaNode object,  Dinitz dinitz,int santaNodeID, ArrayList<SantaNode> toBeIterated) {
		for(SantaNode i: toBeIterated) {
			if(i.numberOfGiftsInTheBag==0) {
				continue;
			}
			dinitz.newEdgeCreation(santaNodeID, i.nodeID, 1);
		}
	}
	
	
	public static void edgesCreator(int sinkID,Dinitz dinitz,
			ArrayList<SantaNode> withA,
			ArrayList<SantaNode> withoutA,
			ArrayList<SantaNode> greenTrainArrayList,ArrayList<SantaNode> redTrainArrayList,
			ArrayList<SantaNode> greenReindeerArrayList,
			ArrayList<SantaNode> redReindeerArrayList
			) {
		
		//LEFTMOST AND MIDDLE PART
		
		for(SantaNode santaNode : withA) {
			if (santaNode.typeOfNode.equals("a")) {
//				if(santaNode.numberOfGiftsInTheBag==0) {
//					System.out.println("A BOS");
//					continue;
//				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenTrainArrayList);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenReindeerArrayList);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redTrainArrayList);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redReindeerArrayList);

				
			}
			
			
			if (santaNode.typeOfNode.equals("ab")) {
//				if(santaNode.numberOfGiftsInTheBag==0) {
//					System.out.println("AB BOS");
//
//					continue;
//				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenTrainArrayList);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenReindeerArrayList);

				
			}
			if (santaNode.typeOfNode.equals("abd")) {
//				if(santaNode.numberOfGiftsInTheBag==0) {
//					System.out.println("ABD BOS");
//
//					continue;
//				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenTrainArrayList);

			}
			if (santaNode.typeOfNode.equals("abe")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenReindeerArrayList);

			}
			if (santaNode.typeOfNode.equals("ac")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redTrainArrayList);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redReindeerArrayList);

			}
			if (santaNode.typeOfNode.equals("acd")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redTrainArrayList);

			}
			if (santaNode.typeOfNode.equals("ace")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redReindeerArrayList);

			}
			if (santaNode.typeOfNode.equals("ad")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenTrainArrayList);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redTrainArrayList);

			}
			if (santaNode.typeOfNode.equals("ae")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenReindeerArrayList);
				AhelperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redReindeerArrayList);

			}
		}
		
		
		for(SantaNode santaNode : withoutA) {
			
			if (santaNode.typeOfNode.equals("b")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenTrainArrayList);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenReindeerArrayList);

				
			}
			if (santaNode.typeOfNode.equals("bd")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenTrainArrayList);

			}
			if (santaNode.typeOfNode.equals("be")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenReindeerArrayList);

			}
			if (santaNode.typeOfNode.equals("c")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redTrainArrayList);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redReindeerArrayList);

			}
			if (santaNode.typeOfNode.equals("cd")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redTrainArrayList);

			}
			if (santaNode.typeOfNode.equals("ce")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redReindeerArrayList);

			}
			if (santaNode.typeOfNode.equals("d")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenTrainArrayList);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redTrainArrayList);

			}
			if (santaNode.typeOfNode.equals("e")) {
				if(santaNode.numberOfGiftsInTheBag==0) {
					continue;
				}
				dinitz.newEdgeCreation(0, santaNode.nodeID, santaNode.numberOfGiftsInTheBag);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, greenReindeerArrayList);
				helperEdgesCreator(santaNode,dinitz, santaNode.nodeID, redReindeerArrayList);

			}
		}
		

			
			
		// RIGHTMOST PART
		for(SantaNode santaNode: greenTrainArrayList) {
			if(santaNode.numberOfGiftsInTheBag==0) {
				continue;
			}
			dinitz.newEdgeCreation(santaNode.nodeID, sinkID-1, santaNode.numberOfGiftsInTheBag);
		}
		for(SantaNode santaNode: redTrainArrayList) {
			if(santaNode.numberOfGiftsInTheBag==0) {
				continue;
			}
			dinitz.newEdgeCreation(santaNode.nodeID, sinkID-1, santaNode.numberOfGiftsInTheBag);
		}
		for(SantaNode santaNode: greenReindeerArrayList) {
			if(santaNode.numberOfGiftsInTheBag==0) {
				continue;
			}
			
			dinitz.newEdgeCreation(santaNode.nodeID, sinkID-1, santaNode.numberOfGiftsInTheBag);
		}
		for(SantaNode santaNode: redReindeerArrayList) {
			if(santaNode.numberOfGiftsInTheBag==0) {
				continue;
			}
			dinitz.newEdgeCreation(santaNode.nodeID, sinkID-1, santaNode.numberOfGiftsInTheBag);
		}
		
	}
	
	
	
	
	
	
	
	
	
	

	public static void othersEdgeCreator(ArrayList<SantaNode> withoutA,Dinitz dinitz,int vehicleNumber, int verticesNumber, int aNode_int, SantaNode aNode,
			int[][] capacitymatrix) {

		
		
		
		

	}

	
	
	///////////////////////////////////////////////////////
//	public static void aEdgeCreator(int vehicleNumber, int verticesNumber, int aNode_int, SantaNode aNode,
//			int[][] capacitymatrix) {
//
//		if (aNode.typeOfNode.equals("a")) {
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("greentrain")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("redtrain")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("greenreindeer")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("redreindeer")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//			}
//		}
//		if (aNode.typeOfNode.equals("ab")) {
//			SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("greentrain")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("greenreindeer")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//			}
//		}
//		if (aNode.typeOfNode.equals("abd")) {
//			SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("greentrain")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//			}
//		}
//		if (aNode.typeOfNode.equals("abe")) {
//			SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("greenreindeer")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//			}
//		}
//		if (aNode.typeOfNode.equals("ac")) {
//			SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("redtrain")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("redreindeer")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//
//				}
//			}
//		}
//		if (aNode.typeOfNode.equals("acd")) {
//			SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("redtrain")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//			}
//		}
//		if (aNode.typeOfNode.equals("ace")) {
//			SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("redreindeer")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//			}
//		}
//		if (aNode.typeOfNode.equals("ad")) {
//			SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("greentrain")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("redtrain")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//			}
//		}
//		if (aNode.typeOfNode.equals("ae")) {
//			SantaGraph.editCapacityMatrix(0, aNode_int, aNode.numberOfGiftsInTheBag);
//
//			for (int i = verticesNumber - vehicleNumber; i < verticesNumber; i++) {
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("greenreindeer")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//				if (SantaGraph.santaNodeArray[i].typeOfNode.equals("redreindeer")) {
//					SantaGraph.editCapacityMatrix(aNode_int, i, 1);
//				}
//			}
//		}
//
//	}

	public static void trainReindeerCapacityArrayUpdater(String newLine, Integer[] arrayToBeUpdated) {

		String[] capacitiesArray = newLine.split(" ");

		for (int i = 0; i < capacitiesArray.length; i++) {
			arrayToBeUpdated[i] = Integer.parseInt(capacitiesArray[i]);
		}

	}

	public static void printer(Integer[] array) {
		for (Integer i : array) {
			System.out.print(i + "  ");
		}
		System.out.println();
	}
	
	public static void printerForArrayList(ArrayList<SantaNode> arrayliste) {
		System.out.println("---------");
		for (SantaNode i : arrayliste) {
			System.out.println(i.toString() + "  ");
		}
	}

}





